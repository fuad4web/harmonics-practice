<?php
     include 'elements/header.php';
?>

     <!-- <div class="container"> -->

     <!-- header  -->
          <div class="header">
               <div class="menu">
                    <nav class="navbar navbar-expand-lg navbar-light">
                         <a class="navbar-brand" href="#">StudioMart</a>
                         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                         <span class="navbar-toggler-icon"></span>
                         </button>

                         <div class="collapse navbar-collapse" id="navbarSupportedContent">
                              <ul class="navbar-nav mr-auto ml-5">
                                   <li class="nav-item px-3 active">
                                        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                                   </li>
                                   <li class="nav-item px-3 active">
                                        <a class="nav-link" href="#">Studios</a>
                                   </li>
                                   <li class="nav-item px-3 active">
                                        <a class="nav-link" href="#">About</a>
                                   </li>
                                   <li class="nav-item px-3 active">
                                        <a class="nav-link" href="#">How it works</a>
                                   </li>
                                   <li class="nav-item px-3 active">
                                        <a class="nav-link text-primary" href="#">Become a Vendor</a>
                                   </li>
                                   <li class="nav-item px-3 active">
                                        <a class="nav-link" href="login">Login</a>
                                   </li>
                                   <li class="nav-item px-3 active">
                                        <a class="nav-link text-light bg-primary jdkhask" href="register">Signup</a>
                                   </li>
                              </ul>
                         </div>
                    </nav>
               </div>
               <div class="front-page text-white p-auto">
                    <p class="sdjkjkas fw-bold">Do you own a Studio? Start Earning</p>
                    <p class="lead klsaskl">List your Studio and Start earning from Bookings.</p>
                    <button class="btn btn-primary p-2 fw-bold">Become a Vendor</button>
               </div>
          </div>
          <div class="main my-3">

          <!-- About Earnings -->
               <div class="about-earning">
                    <p class="earning-header">Start Earning in Just 3 Steps</p>
                    <div class="row">
                         <div class="col-md-4">
                              <div class="earning-box">
                                   <div class="earning-numbery">
                                        01
                                   </div>
                                   <div class="earning-brief">
                                        <p class="para-earning">Add Studio</p>
                                        <p class="para-ejhor">Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam tempore autem eveniet obcaecati voluptate molestias quidem adipisci inventore impedit!</p>
                                   </div>
                              </div>
                         </div>
                         <div class="col-md-4">
                              <div class="earning-box">
                                   <div class="earning-numbery">
                                        02
                                   </div>
                                   <div class="earning-brief">
                                        <p class="para-earning">Get Booked</p>
                                        <p class="para-ejhor">Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam tempore autem eveniet obcaecati voluptate molestias quidem adipisci inventore impedit!</p>
                                   </div>
                              </div>
                         </div>
                         <div class="col-md-4">
                              <div class="earning-box">
                                   <div class="earning-numbery">
                                        03
                                   </div>
                                   <div class="earning-brief">
                                        <p class="para-earning">Receive Payment</p>
                                        <p class="para-ejhor">Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam tempore autem eveniet obcaecati voluptate molestias quidem adipisci inventore impedit!</p>
                                   </div>
                              </div>
                         </div>
                    </div>
                    <div class="submit-nutton my-5 text-center">
                         <button class="btn btn-primary p-3">Become a Vendor</button>
                    </div>
               </div>

               <!-- Download Apps -->
               <section class="mobile-app text-dark p-5 text-sm-start">
                    <div class="d-md-flex justify-content-around align-items-between container">
                         <img src="asset/images/phone.PNG" class="img-fluid d-sm-block position-relative" alt="Phone SVG">
                         <div class="market-phone">
                              <p class="phone-header">
                                   Download the
                                   <br>
                                   Mobile App
                              </p>
                              <p class="mt-4 mb-5 khsdklh">StudioMart is available on Playstore.</p>
                              <img src="asset/images/google-black.PNG" class="img-fluid" alt="">
                         </div>
                    </div>
               </section>

               <!-- Rent a Studio -->
               <section class="container why-studio my-5">
                    <div class="row">
                         <div class="col-md-6">
                              <div class="d-flex justify-content-between row-nowrap">
                                   <div class="mt-1">
                                        <i class="fas fa-circle"></i>
                                   </div>
                                   &nbsp;&nbsp;&nbsp;
                                   <div>
                                        <p class="why-subheader">Rent a Studio</p>
                                        <p class="why-notes">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Est velit iusto blanditiis ipsum tempore! Alias a error eligendi amet?</p>
                                   </div>
                              </div>
                         </div>
                         <div class="col-md-6">
                              <div class="d-flex justify-content-between row-nowrap">
                                   <div class="mt-1">
                                        <i class="fas fa-circle"></i>
                                   </div>
                                   &nbsp;&nbsp;&nbsp;
                                   <div>
                                        <p class="why-subheader">Rent a Studio</p>
                                        <p class="why-notes">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Est velit iusto blanditiis ipsum tempore! Alias a error eligendi amet?</p>
                                   </div>
                              </div>
                         </div>
                         <div class="col-md-6">
                              <div class="d-flex justify-content-between row-nowrap">
                                   <div class="mt-1">
                                        <i class="fas fa-circle"></i>
                                   </div>
                                   &nbsp;&nbsp;&nbsp;
                                   <div>
                                        <p class="why-subheader">Rent a Studio</p>
                                        <p class="why-notes">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Est velit iusto blanditiis ipsum tempore! Alias a error eligendi amet?</p>
                                   </div>
                              </div>
                         </div>
                         <div class="col-md-6">
                              <div class="d-flex justify-content-between row-nowrap">
                                   <div class="mt-1">
                                        <i class="fas fa-circle"></i>
                                   </div>
                                   &nbsp;&nbsp;&nbsp;
                                   <div>
                                        <p class="why-subheader">Rent a Studio</p>
                                        <p class="why-notes">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Est velit iusto blanditiis ipsum tempore! Alias a error eligendi amet?</p>
                                   </div>
                              </div>
                         </div>
                    </div>
               </section>

               <!-- Frequently Asked Question  -->
               <section class="container faq my-5">
                    <p class="faq-header">Frequently Asked Question</p>
                    <div class="accordion accordion-flush" id="accordionFlushExample">
                         <div class="accordion-item my-4">
                              <h2 class="accordion-header" id="flush-headingOne">
                                   <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                   What is StudioMart?
                                   </button>
                              </h2>
                              <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                   <div class="accordion-body">Placeholder content for this accordion, which is intended to demonstrate the <code>.accordion-flush</code> class. This is the first item's accordion body.</div>
                              </div>
                         </div>
                         <div class="accordion-item my-4">
                              <h2 class="accordion-header" id="flush-headingTwo">
                                   <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                                   How do I add my studio?
                                   </button>
                              </h2>
                              <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                                   <div class="accordion-body">Placeholder content for this accordion, which is intended to demonstrate the <code>.accordion-flush</code> class. This is the second item's accordion body. Let's imagine this being filled with some actual content.</div>
                              </div>
                         </div>
                         <div class="accordion-item my-4">
                              <h2 class="accordion-header" id="flush-headingThree">
                                   <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                                   How do I receive Payment?
                                   </button>
                              </h2>
                              <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                                   <div class="accordion-body">Placeholder content for this accordion, which is intended to demonstrate the <code>.accordion-flush</code> class. This is the third item's accordion body. Nothing more exciting happening here in terms of content, but just filling up the space to make it look, at least at first glance, a bit more representative of how this would look in a real-world application.</div>
                              </div>
                         </div>
                         
                         <div class="accordion-item my-4">
                              <h2 class="accordion-header" id="flush-headingFour">
                                   <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                                   How do I verify my Studio?
                                   </button>
                              </h2>
                              <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#accordionFlushExample">
                                   <div class="accordion-body">Placeholder content for this accordion, which is intended to demonstrate the <code>.accordion-flush</code> class. This is the third item's accordion body. Nothing more exciting happening here in terms of content, but just filling up the space to make it look, at least at first glance, a bit more representative of how this would look in a real-world application.</div>
                              </div>
                         </div>
                    </div>
               </section>

          </div>
     
     <?php
          include 'elements/footer.php';
     ?>
