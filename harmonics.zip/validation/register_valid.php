<?php 

include '../core/init.php';

if(isset($_POST['signup'])) {

  $first_name = $_POST['first_name'];
  $last_name = $_POST['last_name'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $confirm_password = $_POST['confirm_password'];

  if(!empty($first_name) || !empty($last_name) || !empty($email) || !empty($password) || !empty($confirm_password)) {

      $first_name = $getFromU->checkInput($first_name);
      $last_name = $getFromU->checkInput($last_name);
      $email = $getFromU->checkInput($email);
      $password = $getFromU->checkInput($password);
      $confirm_password = $getFromU->checkInput($confirm_password);

      if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
         $_SESSION['ErrorMessage'] = "Invalid Email Address";
         header('Location: ../register');
      } else {

          if($getFromU->check_exist_one_col('users', 'email', $email) === true) {
            $_SESSION['ErrorMessage'] = "Email Address Already used";
            header('Location: ../register');
          } else {

            if($password !== $confirm_password) {
                  $_SESSION['ErrorMessage'] = "Password didn't match";
                  header('Location: ../register');
                } else {
                  
                  $password = md5($password);
                  $getFromU->create('users', compact('first_name', 'last_name', 'email', 'password'));
                  echo '<script>alert("Registration Successful");</script>';
                  $_SESSION['SuccessMessage'] = "Registration Successful";
                  header('Location: ../register');

            }
            
         }
      }
  }
}

?>
