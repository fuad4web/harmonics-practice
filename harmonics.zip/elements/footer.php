
     <div class="footer bg-dark text-white mt-4">
          <div class="container py-4">
               <div class="row py-5">
                    <div class="col-md-3">
                         <ul>
                              <li class="" style="font-size: 41px; font-weight: 600;">StudioMart</li>
                              <li>Rent a Studio</li>
                              <li>Add a Studio</li>
                              <li><img src="asset/images/google-white.PNG" class="img-fluid" alt=""></li>
                         </ul>
                         
                    </div>
                    <div class="col-md-3">
                         <ul>
                              <li class="hkdsk lead">Studio Category</li>
                              <li>Music Studio</li>
                              <li>Photo Studio</li>
                              <li>Make Up Studio</li>
                              <li>Art Studio</li>
                              <li>Podcast Studio</li>
                         </ul>
                    </div>
                    <div class="col-md-3">
                         <ul>
                              <li class="hkdsk lead">Company</li>
                              <li>About Us</li>
                              <li>Contact</li>
                         </ul>
                    </div>
                    <div class="col-md-3">
                         <ul>
                              <li class="hkdsk lead">Support</li>
                              <li>Studio Fee</li>
                              <li>Terms & Conditions</li>
                              <li>Privacy</li>
                         </ul>
                    </div>
               </div>
               <hr>
               <div class="row my-4 text-white">
                    <div class="d-sm-flex justify-content-between row-wrap">
                         <div class="copyright">
                              &copy; StudioMart 2022. All Rights Reserved.
                         </div>
                         <div class="d-flex justify-content-between social-media">
                              <a href="#" style="text-decoration: none; font-size: 20px; color: #fff;"><i class="fa-brands fa-instagram text-white" aria-hidden="true"></i></a> &nbsp;&nbsp;&nbsp;
                              <a href="#" style="text-decoration: none; font-size: 20px; color: #fff;"><i class="fa-brands fa-twitter text-white" aria-hidden="true"></i></a> &nbsp;&nbsp;&nbsp;
                              <a href="#" style="text-decoration: none; font-size: 20px; color: #fff;"><i class="fa-brands fa-linkedin-in text-white" aria-hidden="true"></i></a> &nbsp;&nbsp;&nbsp;
                              <a href="#" style="text-decoration: none; font-size: 20px; color: #fff;"><i class="fa-brands fa-facebook-f text-white" aria-hidden="true"></i></a>
                         </div>
                    </div> 
               </div>
          </div>
     </div>
     <!-- </div> -->
     <script src="asset/js/jquery.js"></script>
     <script src="asset/js/bootstrap.bundle.min.js"></script>
     <script src="asset/js/bootstrap.min.js"></script>
</body>
</html>
