<?php
     include 'core/init.php';
?>

<!DOCTYPE html>
<html lang="en">
     <head>
          <meta charset="UTF-8">
          <meta http-equiv="X-UA-Compatible" content="IE=edge">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Simple Page Website</title>
          <link rel="stylesheet" href="asset/css/bootstrap.min.css">
          <link rel="stylesheet" href="asset/css/register.css">
          <link rel="stylesheet" href="asset/css/font-awesome.min.css">
          <link rel="stylesheet" href="asset/css/bootstrap-grid.min.css">
     </head>
     <body>

     <section class="h-58 bg-dark">
          <div class="h-58 klhdskhsd">
               <div class="row d-flex justify-content-center align-items-center h-58">
                    <div class="col">
                         <div class="card card-registration">
                              <div class="row g-5">

                                   <div class="col-xl-6 d-xl-block klnlask text-white">
                                        <div class="ljkxhuisd">
                                             <h3 class="signup-head mb-5 fw-bolder">Sign Up to Studiomart</h3>
                                             <p class="signup-text">Already have an Account? You can <a href="login" class="text-primary" style="text-decoration: none;">Sign in here</a></p>
                                        </div>
                                   </div>

                                   <div class="col-xl-6">
                                        <div class="card-body p-md-5 text-black">
                                             <div class="text-center">
                                                  <h3 class="text-capitalize">Sign Up</h3>
                                                  <p>Signup to get started</p>
                                             </div>

                                             <?php
                                                  echo SuccessMessage();
                                                  echo ErrorMessage();
                                             ?>

                                             <form action="validation/register_valid.php" method="post">
                                                  <div class="form-outline">
                                                       <label class="form-label" for="form3Example1m">First name</label>
                                                       <input type="text" id="form3Example1m" name="first_name" placeholder="Enter your First Name" class="form-control form-control-lg" required />
                                                  </div>
                                                  <br>
                                                  <div class="form-outline">
                                                       <label class="form-label" for="form3Example1n">Last name</label>
                                                       <input type="text" id="form3Example1n" name="last_name" placeholder="Enter your Last Name" class="form-control form-control-lg" required />
                                                  </div>
     <br>
                                                  <div class="form-outline">
                                                       <label class="form-label" for="form3Example1m1">Email Address</label>
                                                       <input type="email" id="form3Example1m1" name="email" placeholder="Enter your Email address" class="form-control form-control-lg" required />
                                                  </div>
                                                  <br>
                                                  <div class="form-outline">
                                                       <label class="form-label" for="form3Example1n1">Password</label>
                                                       <input type="password" id="form3Example1n1" name="password" placeholder="Enter your Password" class="form-control form-control-lg" required />
                                                  </div>
                                                  <br>
                                                  <div class="form-outline mb-2">
                                                       <label class="form-label" for="form3Example8">Re-enter Password</label>
                                                       <input type="password" id="form3Example8" name="confirm_password" placeholder="Confirm your Password" class="form-control form-control-lg" required />
                                                  </div>
     <br>
                                                  <div class="form-check form-check-inline my-0">
                                                       <input class="form-check-input" type="checkbox" name="inlineRadioOptions" id="otherGender"
                                                       value="option3" required />
                                                       <label class="form-check-label" for="otherGender">I have read, understood and accept the <span class="text-primary">Terms and Conditions</span>.</label>
                                                  </div>
     <br>
                                                  <div class="d-flex justify-content-center pt-3">
                                                       <button type="submit" name="signup" class="btn btn-primary btn-lg w-75">Sign Up</button>
                                                  </div>
                                             </form>

                                        </div>
                                   </div>
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </section>
          
     <script src="asset/js/jquery.js"></script>
     <script src="asset/js/bootstrap.bundle.min.js"></script>
     <script src="asset/js/bootstrap.min.js"></script>
     </body>
</html>
